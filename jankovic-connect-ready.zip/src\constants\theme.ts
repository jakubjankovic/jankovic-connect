export const colors = {
  background: '#0B0F14',
  surface: '#111827',
  surfaceSoft: '#1F2937',
  emerald: '#10B981',
  emeraldDark: '#047857',
  gold: '#D4AF37',
  text: '#F9FAFB',
  muted: '#9CA3AF',
  border: 'rgba(255,255,255,0.10)',
  danger: '#F87171',
  success: '#34D399',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const radius = {
  sm: 10,
  md: 16,
  lg: 22,
  pill: 999,
};

export const font = {
  hero: 30,
  title: 22,
  subtitle: 16,
  body: 15,
  small: 13,
};
