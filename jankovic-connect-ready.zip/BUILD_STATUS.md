# BUILD STATUS — Jankovič Connect

_Last updated: 2026-05-20 · React Native CLI + TypeScript + native Android (unchanged architecture)._

This file is an honest handoff. It records what was verified, what could not be verified in the automated environment, and exactly what to run locally.

---

## ✅ Successfully verified (here)

- **React Native CLI structure** matches the official RN 0.74 template (not Expo, not PWA, not Kotlin-only).
- **Toolchain installed & verified on this machine:**
  - Node.js `v24.15.0` (`C:\Program Files\nodejs`)
  - JDK `17.0.19 LTS` (`C:\Program Files\Microsoft\jdk-17.0.19.10-hotspot`)
  - Android SDK at `C:\Android\Sdk` — `platform-tools`, `platforms;android-34`, `build-tools;34.0.0`
  - `adb` version `1.0.41`
  - Env vars persisted: `JAVA_HOME`, `ANDROID_HOME`, `ANDROID_SDK_ROOT`; `platform-tools` on PATH
- **`npm install`** — 878 packages, no errors.
- **`npm run typecheck` (tsc --noEmit)** — PASSES (exit 0).
- **Gradle wrapper complete** — `gradlew`, `gradlew.bat`, `gradle-wrapper.properties`, and `gradle-wrapper.jar` (43,462 bytes, Gradle 8.6) all present.
- **Autolinking** — official RN 0.74 form: `com.facebook.react.settings` plugin in `settings.gradle` + `autolinkLibrariesWithApp()` in `app/build.gradle`.
- **Libraries present & wired:** `react-native-nfc-manager`, `react-native-qrcode-svg`, `react-native-svg`, `@react-native-clipboard/clipboard`, `@react-navigation/native`.
- **Native module registered** — `ContactPackage()` added in `MainApplication.kt`; `ContactModule.kt` uses `ACTION_INSERT`.
- **AndroidManifest** — declares `android.permission.NFC` + `uses-feature android.hardware.nfc required="false"`; only other permission is `INTERNET`.
- **No unnecessary permissions** — no `CALL_PHONE` (uses `tel:` dialer), no `WRITE_CONTACTS`/`READ_CONTACTS` (uses the insert intent), no contact-write permission needed.
- **Debug signing** — uses AGP's auto-generated default debug keystore; no hand-made keystore required.

## ⚠️ Could NOT be verified here

- **`gradlew.bat assembleDebug` (the actual APK build).** Gradle 8.6 downloaded successfully, then failed before reaching any project compilation.

## Why Gradle could not build inside this environment

The automated sandbox **cannot create a Java NIO `Selector`**. A 2-line Java probe (`Selector.open()`) fails with `java.io.IOException: Unable to establish loopback connection`, root-caused to `java.net.SocketException: Invalid argument: connect` in `sun.nio.ch.UnixDomainSockets.connect0` — i.e. the JVM's selector self-pipe uses an **AF_UNIX socket that this environment blocks**. A plain `127.0.0.1` TCP connect works, but the selector self-pipe does not.

Gradle launches a worker/daemon JVM and communicates with it over a selector-backed socket, so it dies at **JVM/Gradle startup, before parsing the build scripts or compiling anything**. Tried and ruled out: disabling the daemon, single in-process worker, short `java.io.tmpdir`, `-Djava.net.preferIPv4Stack=true`, forcing the classic `WindowsSelectorProvider`, and disabling the tool sandbox — all fail identically because the limitation is at the OS/network layer of the automation context.

## Why this does NOT mean the app code is broken

- The failure is **environmental** (a blocked OS socket capability), not a compile/lint/type error. It happens before Gradle even reads `build.gradle`.
- Everything that does **not** require a NIO selector passed: dependency install, TypeScript typecheck, structure/autolinking/manifest/native-registration audits.
- A **normal interactive Windows session and Android Studio** have working AF_UNIX/selector sockets, so the same `gradlew.bat assembleDebug` is expected to compile straight through with the already-installed toolchain.

## Exact commands to run locally (normal PowerShell)

```powershell
cd "C:\Users\Jakub Jankovič\Documents\Claude VibeCode Session"
npm install
npm run typecheck
cd android
.\gradlew.bat assembleDebug
```

APK output:

```
android\app\build\outputs\apk\debug\app-debug.apk
```

Install on a connected phone (USB debugging on):

```powershell
adb devices
adb install -r android\app\build\outputs\apk\debug\app-debug.apk
```

Live development with Metro instead:

```powershell
npx react-native run-android
```

## Placeholders you still must replace

| Placeholder | Files |
| --- | --- |
| `PUBLIC_CARD_URL_PLACEHOLDER` | `src/constants/profile.ts`, `landing-page/script.js` |
| `GOOGLE_CALENDAR_BOOKING_LINK_PLACEHOLDER` | `src/constants/profile.ts`, `landing-page/script.js` |
