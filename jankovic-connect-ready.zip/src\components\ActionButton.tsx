import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {colors, font, radius, spacing} from '../constants/theme';

type Variant = 'primary' | 'secondary' | 'ghost';

interface Props {
  label: string;
  onPress: () => void;
  variant?: Variant;
  icon?: string;
  loading?: boolean;
  success?: boolean;
  successLabel?: string;
}

export default function ActionButton({
  label,
  onPress,
  variant = 'secondary',
  icon,
  loading,
  success,
  successLabel,
}: Props) {
  const isPrimary = variant === 'primary';
  const isGhost = variant === 'ghost';

  return (
    <Pressable
      onPress={onPress}
      disabled={loading}
      style={({pressed}) => [
        styles.base,
        isPrimary && styles.primary,
        isGhost && styles.ghost,
        !isPrimary && !isGhost && styles.secondary,
        success && styles.success,
        pressed && styles.pressed,
      ]}>
      <View style={styles.row}>
        {icon ? <Text style={styles.icon}>{icon}</Text> : null}
        {loading ? (
          <ActivityIndicator color={colors.text} />
        ) : (
          <Text
            style={[
              styles.label,
              isPrimary && styles.labelPrimary,
              success && styles.labelSuccess,
            ]}>
            {success && successLabel ? successLabel : label}
          </Text>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: radius.md,
    paddingVertical: 15,
    paddingHorizontal: spacing.lg,
    marginVertical: spacing.xs + 2,
    borderWidth: 1,
    borderColor: colors.border,
  },
  primary: {
    backgroundColor: colors.emerald,
    borderColor: colors.emeraldDark,
    shadowColor: colors.emerald,
    shadowOpacity: 0.35,
    shadowRadius: 12,
    shadowOffset: {width: 0, height: 4},
    elevation: 4,
  },
  secondary: {
    backgroundColor: colors.surfaceSoft,
  },
  ghost: {
    backgroundColor: 'transparent',
  },
  success: {
    backgroundColor: colors.emeraldDark,
    borderColor: colors.emerald,
  },
  pressed: {
    opacity: 0.7,
    transform: [{scale: 0.985}],
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    fontSize: font.subtitle,
    marginRight: spacing.sm,
  },
  label: {
    color: colors.text,
    fontSize: font.body,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  labelPrimary: {
    color: '#04130D',
    fontWeight: '700',
  },
  labelSuccess: {
    color: colors.text,
  },
});
