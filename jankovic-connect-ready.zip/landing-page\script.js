/* Jakub Benjamin Jankovič — Digital Contact Hub
 * Static landing page logic: links, clipboard, and vCard download.
 */

// === Configuration — keep in sync with the app ===
var PROFILE = {
  fullName: 'Jakub Benjamin Jankovič',
  firstName: 'Jakub Benjamin',
  lastName: 'Jankovič',
  phone: '+421 903 703 725',
  phoneDial: '+421903703725',
  email: 'jakubjankovic100@gmail.com',
  linkedin:
    'https://www.linkedin.com/in/jakub-benjamin-jankovi%C4%8D-b7929320b/?skipRedirect=true',
  facebook: 'https://www.facebook.com/profile.php?id=100022833794468',
  title: 'Banking • Networking • Client Relationships',
};

// Replace these two placeholders with your real values (see README).
var PUBLIC_CARD_URL = 'PUBLIC_CARD_URL_PLACEHOLDER';
var BOOKING_LINK = 'GOOGLE_CALENDAR_BOOKING_LINK_PLACEHOLDER';

function $(id) {
  return document.getElementById(id);
}

function toast(message) {
  var el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(function () {
    el.classList.remove('show');
  }, 2000);
}

function markSuccess(btn, label) {
  var original = btn.innerHTML;
  btn.classList.add('is-success');
  btn.innerHTML = '<span class="ico">✓</span> ' + label;
  setTimeout(function () {
    btn.classList.remove('is-success');
    btn.innerHTML = original;
  }, 2000);
}

function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text);
  }
  return new Promise(function (resolve) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
    } catch (e) {}
    document.body.removeChild(ta);
    resolve();
  });
}

function buildVCard() {
  var lines = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    'N:' + PROFILE.lastName + ';' + PROFILE.firstName + ';;;',
    'FN:' + PROFILE.fullName,
    'TITLE:' + PROFILE.title,
    'TEL;TYPE=CELL:' + PROFILE.phoneDial,
    'EMAIL;TYPE=WORK:' + PROFILE.email,
    'URL:' + PUBLIC_CARD_URL,
    'X-SOCIALPROFILE;TYPE=linkedin:' + PROFILE.linkedin,
    'X-SOCIALPROFILE;TYPE=facebook:' + PROFILE.facebook,
    'NOTE:LinkedIn: ' + PROFILE.linkedin + '\\nFacebook: ' + PROFILE.facebook,
    'END:VCARD',
  ];
  return lines.join('\r\n');
}

function downloadVCard() {
  var blob = new Blob([buildVCard()], {type: 'text/vcard;charset=utf-8'});
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'jakub-benjamin-jankovic-contact.vcf';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(function () {
    URL.revokeObjectURL(url);
  }, 1000);
}

document.addEventListener('DOMContentLoaded', function () {
  $('linkedin').href = PROFILE.linkedin;
  $('facebook').href = PROFILE.facebook;
  $('email').href = 'mailto:' + PROFILE.email;
  $('call').href = 'tel:' + PROFILE.phoneDial;
  $('booking').href = BOOKING_LINK;

  $('saveContact').addEventListener('click', function () {
    downloadVCard();
    toast('Kontakt stiahnutý');
  });

  $('copyEmail').addEventListener('click', function () {
    var btn = this;
    copyText(PROFILE.email).then(function () {
      markSuccess(btn, 'Email skopírovaný');
      toast('Email skopírovaný');
    });
  });
});
