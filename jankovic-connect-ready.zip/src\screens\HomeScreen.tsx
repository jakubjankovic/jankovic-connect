import React, {useState} from 'react';
import {ScrollView, StyleSheet, Text, View} from 'react-native';
import type {NativeStackScreenProps} from '@react-navigation/native-stack';
import type {RootStackParamList} from '../types/navigation';
import {colors, font, spacing} from '../constants/theme';
import {PROFILE, TEXTS} from '../constants/profile';
import Hero from '../components/Hero';
import Card from '../components/Card';
import SectionTitle from '../components/SectionTitle';
import ActionButton from '../components/ActionButton';
import Disclaimer from '../components/Disclaimer';
import {
  callPhone,
  copyEmail,
  openBooking,
  openEmail,
  openFacebook,
  openLinkedIn,
  saveContact,
} from '../utils/actions';

type Props = NativeStackScreenProps<RootStackParamList, 'Home'>;

export default function HomeScreen({navigation}: Props) {
  const [emailCopied, setEmailCopied] = useState(false);

  const handleCopyEmail = () => {
    copyEmail();
    setEmailCopied(true);
    setTimeout(() => setEmailCopied(false), 2000);
  };

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}>
      <Hero intro={PROFILE.shortIntro} />

      <Card>
        <SectionTitle title="Quick Actions" subtitle="Spoj sa so mnou" />
        <ActionButton
          label="Save Contact"
          icon="👤"
          variant="primary"
          onPress={saveContact}
        />
        <ActionButton
          label="Connect on LinkedIn"
          icon="in"
          onPress={openLinkedIn}
        />
        <ActionButton label="Send Email" icon="✉️" onPress={openEmail} />
        <ActionButton
          label="Copy Email"
          icon="📋"
          onPress={handleCopyEmail}
          success={emailCopied}
          successLabel="Email skopírovaný ✓"
        />
        <ActionButton label="Call" icon="📞" onPress={callPhone} />
        <ActionButton label="Open Facebook" icon="f" onPress={openFacebook} />
      </Card>

      <Card>
        <SectionTitle
          title="Book a Meeting"
          subtitle="Real-time Google Calendar"
        />
        <Text style={styles.bookingText}>{TEXTS.bookingText}</Text>
        <Text style={styles.bookingHelper}>{TEXTS.bookingHelper}</Text>
        <ActionButton
          label="Book a Meeting"
          icon="📅"
          variant="primary"
          onPress={openBooking}
        />
      </Card>

      <Card>
        <SectionTitle title="Networking Tools" subtitle="Zdieľaj a zapisuj" />
        <ActionButton
          label="Share My Card"
          icon="🔳"
          variant="primary"
          onPress={() => navigation.navigate('ShareCard')}
        />
        <ActionButton
          label="NFC Setup"
          icon="📶"
          onPress={() => navigation.navigate('NfcSetup')}
        />
        <ActionButton
          label="Follow-up Helper"
          icon="✍️"
          onPress={() => navigation.navigate('FollowUpHelper')}
        />
      </Card>

      <View style={styles.contactInfo}>
        <Text style={styles.infoLine}>{PROFILE.phone}</Text>
        <Text style={styles.infoLine}>{PROFILE.email}</Text>
      </View>

      <Disclaimer />
      <Text style={styles.footer}>{TEXTS.footer}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: colors.background},
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  bookingText: {
    color: colors.text,
    fontSize: font.body,
    lineHeight: 22,
  },
  bookingHelper: {
    color: colors.muted,
    fontSize: font.small,
    marginTop: spacing.xs,
    marginBottom: spacing.md,
  },
  contactInfo: {
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  infoLine: {
    color: colors.muted,
    fontSize: font.small,
    marginVertical: 1,
  },
  footer: {
    color: colors.gold,
    fontSize: font.small,
    fontWeight: '700',
    letterSpacing: 1.5,
    textAlign: 'center',
    marginTop: spacing.lg,
    textTransform: 'uppercase',
  },
});
