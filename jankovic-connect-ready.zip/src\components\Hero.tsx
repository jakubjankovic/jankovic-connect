import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {colors, font, radius, spacing} from '../constants/theme';
import {PROFILE} from '../constants/profile';

interface Props {
  intro?: string;
}

export default function Hero({intro}: Props) {
  const initials = 'JBJ';
  return (
    <View style={styles.wrap}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>{initials}</Text>
      </View>
      <Text style={styles.name}>{PROFILE.fullName}</Text>
      <View style={styles.headlinePill}>
        <Text style={styles.headline}>{PROFILE.headline}</Text>
      </View>
      {intro ? <Text style={styles.intro}>{intro}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    paddingTop: spacing.lg,
    paddingBottom: spacing.lg,
  },
  avatar: {
    width: 84,
    height: 84,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceSoft,
    borderWidth: 2,
    borderColor: colors.emerald,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
    shadowColor: colors.emerald,
    shadowOpacity: 0.4,
    shadowRadius: 18,
    shadowOffset: {width: 0, height: 0},
    elevation: 6,
  },
  avatarText: {
    color: colors.gold,
    fontSize: font.title,
    fontWeight: '800',
    letterSpacing: 1,
  },
  name: {
    color: colors.text,
    fontSize: font.hero,
    fontWeight: '800',
    textAlign: 'center',
    letterSpacing: 0.3,
  },
  headlinePill: {
    marginTop: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  headline: {
    color: colors.gold,
    fontSize: font.small,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  intro: {
    color: colors.muted,
    fontSize: font.body,
    lineHeight: 22,
    textAlign: 'center',
    marginTop: spacing.lg,
    paddingHorizontal: spacing.sm,
  },
});
